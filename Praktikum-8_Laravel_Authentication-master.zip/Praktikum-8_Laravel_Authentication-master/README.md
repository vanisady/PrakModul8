Praktikum MODUL 8
LARAVEL AUTHENTICATION

Pada praktikum kali ini kita akan melanjutkan belajar tentang Laravel Authentication. Mahasiswa akan mencoba menerapkan fitur login dan lain-lain pada sebuah project laravel. 
Kegiatan ini dilakukan agar mahasiswa dapat menerapkan fitur authentication untuk mendukung sebuah pengembangan aplikasi web berbasis laravel.

